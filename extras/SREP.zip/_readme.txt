DISCLAIMER:

Any changes you make or do from the result of using this software is done so under your own admission and you take full responsibility for the consequences of your actions.
It is advised that you have a chip programmer available and that you have made a backup of your BIOS before performing any actions with this software.
This software was created by SmokeyCPU/Smokey/Smokeless/SmokelessCPUv2/AARCH64_EL3 https://github.com/SmokelessCPUv2/SmokelessRuntimeEFIPatcher

Step-by-step:
0) format a fat32 usb drive and place all files into the root folder
1) boot into the steam deck's bios
2) go to "run file" menu (bottom left)
3) run RUNTIME-PATCHER.efi
4) go back and go to the 'setup' option in the bottom right

- CBS and PBS are both loaded from the BIOS, they are 'cut down' versions than what was available previously
- Advanced menu has to be used to unlock TDP (maximum limit has been risen to 30w) and maximum GPU and CPU frequencies (setting present in 109 bios)
- The UI dissapears after a reboot (the values are saved) and steps 3 and 4 have to be repeated in case if you want to change something again.
- The 3-button bios recovery feature is supposed to work just fine in case of a "brick"

RUS:
Пошаговая инструкция: 
0)отформатируйте юсб флешку как fat32 и скопируйте все файлы в корень
1)зайдите в биос
2)зайдите в менюшку в левом нижнем углу (run file вроде)
3)запустите RUNTIME-PATCHER.efi
4) Вернитесь назад и выберите опцию «настройка» в правом нижнем углу.

- CBS и PBS загружаются из BIOS, это урезанные версии по сравнению с тем, что было доступно ранее.
- Меню Advanced должно быть использовано для изменения TDP вместо меню CBS (30w max), т.к. через CBS не работает. Идентичная ситуация с максимальной частотой (gfx/cpuclkFmaxoverride), которые добавили в 109 биосе оледа
- После перезагрузки меню пропадает, но указанные значения сохраняются. По необходимости шаги 3 и 4 можно повторить, чтобы активировать меню заново
- Комбинация 3-х кнопок для восстановления биоса должна работать (в теории)


CREDIT/БЛАГОДАРНОСТЬ: stanto (stanto.com), sub5ist, smokeycpu (smokelesscpuv2), mytrixx |--- on discord